export default function Aquarius() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>♈ Aquarius Horoscope</h1>
      <p>You had a weird idea. It might actually be genius.</p>
    </div>
  );
}