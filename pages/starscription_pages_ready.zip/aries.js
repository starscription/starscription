export default function Aries() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>♈ Aries Horoscope</h1>
      <p>You’re charging ahead like a caffeinated ram today. Maybe take one deep breath.</p>
    </div>
  );
}