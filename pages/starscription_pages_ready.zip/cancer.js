export default function Cancer() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>♈ Cancer Horoscope</h1>
      <p>You feel everything today. Even the Wi-Fi signal’s emotions.</p>
    </div>
  );
}