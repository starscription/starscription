export default function Capricorn() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>♈ Capricorn Horoscope</h1>
      <p>You’re working hard. Someone clap. Anyone?</p>
    </div>
  );
}