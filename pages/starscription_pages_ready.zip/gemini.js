export default function Gemini() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>♈ Gemini Horoscope</h1>
      <p>Talking to yourself is fine. Just don’t interrupt.</p>
    </div>
  );
}