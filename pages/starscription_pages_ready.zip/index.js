export default function Home() {
  return (
    <div>
      <h1>Welcome to Starscription!</h1>
      <p>Your personalized horoscopes await...</p>
    </div>
  );
}
