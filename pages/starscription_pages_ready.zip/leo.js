export default function Leo() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>♈ Leo Horoscope</h1>
      <p>The spotlight is yours, even if it’s just the fridge light.</p>
    </div>
  );
}