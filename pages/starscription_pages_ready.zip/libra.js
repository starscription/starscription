export default function Libra() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>♈ Libra Horoscope</h1>
      <p>You can’t decide what to wear, but somehow it’s a vibe.</p>
    </div>
  );
}