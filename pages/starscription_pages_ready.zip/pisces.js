export default function Pisces() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>♈ Pisces Horoscope</h1>
      <p>Floating in a daydream? Perfect. Just don’t forget pants.</p>
    </div>
  );
}