export default function Sagittarius() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>♈ Sagittarius Horoscope</h1>
      <p>Wanderlust activated. You might walk to the kitchen with purpose.</p>
    </div>
  );
}