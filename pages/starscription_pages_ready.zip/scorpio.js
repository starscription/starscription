export default function Scorpio() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>♈ Scorpio Horoscope</h1>
      <p>Mysterious and intense. Basically a walking Netflix drama.</p>
    </div>
  );
}