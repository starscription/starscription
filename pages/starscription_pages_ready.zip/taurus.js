export default function Taurus() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>♈ Taurus Horoscope</h1>
      <p>Stubborn? Maybe. Delicious snacks? Absolutely.</p>
    </div>
  );
}