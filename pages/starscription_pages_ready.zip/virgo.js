export default function Virgo() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>♈ Virgo Horoscope</h1>
      <p>You organized your sock drawer alphabetically. Again.</p>
    </div>
  );
}